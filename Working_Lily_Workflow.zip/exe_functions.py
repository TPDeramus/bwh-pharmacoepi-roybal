import os
import sys
import pandas as pd
from os import path

def build_path(folder, fname):
#basedir = getattr(sys.executable, path.abspath(path.dirname(__file__)))
	#basedir = sys.executable
	bundle_dir = os.getcwd()
	#print("basedir: ", basedir)
	#print("sys.executable: ", sys.executable)
	#bundle_dir = path.dirname(basedir)
	# Original
	return path.abspath(path.join(bundle_dir, folder, fname))

def append_row(df, row):
    return pd.concat([
                df, 
                pd.DataFrame([row], columns=row.index)]
           ).reset_index(drop=True)